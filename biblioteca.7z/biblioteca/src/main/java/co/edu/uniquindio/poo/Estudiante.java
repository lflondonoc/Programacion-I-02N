package co.edu.uniquindio.poo;

public class Estudiante extends Persona{
   private int cantidadPrestamos;

public Estudiante(String nombre, String cedula, String telefono, String correo, int cantidadPrestamos) {
    super(nombre, cedula, telefono, correo);
    this.cantidadPrestamos = cantidadPrestamos;
}

public int getCantidadPrestamos() {
    return cantidadPrestamos;
}

public void setCantidadPrestamos(int cantidadPrestamos) {
    this.cantidadPrestamos = cantidadPrestamos;
}

@Override
public String toString() {
    return "Estudiante [nombre=" + nombre + ", cantidadPrestamos=" + cantidadPrestamos + ", cedula=" + cedula
            + ", telefono=" + telefono + ", correo=" + correo + "]";
}
   
   
}
