package co.edu.uniquindio.poo;

public class DetallePrestamo {
    private int cantidadPrestamos;
    private Libro libro;

    public DetallePrestamo(int cantidadPrestamos, Libro libro) {
        this.cantidadPrestamos = cantidadPrestamos;
        
    }
    public int getCantidadPrestamos() {
        return cantidadPrestamos;
    }
    public Libro getLibro() {
        return libro;
    }
    public void setLibro(Libro libro) {
        this.libro = libro;
    }
    public void setCantidadPrestamos(int cantidadPrestamos) {
        this.cantidadPrestamos = cantidadPrestamos;
    }

    @Override
    public String toString() {
        return "DetallePrestamo [cantidadPrestamos=" + cantidadPrestamos + "]";
    }


}
